import os
import sys
import subprocess

BANNER = """
                                                                         
 ,-----.       ,--.                                                     
'  .--./,--.--.`--',--,--,--. ,---.  ,---.  ,---. ,---. ,--,--,  ,---.  
|  |    |  .--',--.|        || .-. :(  .-' | .--'| .-. :|      \| .-. : 
'  '--'\|  |   |  ||  |  |  |\   --..-'  `)\ `--.\   --.|  ||  |\   --. 
 `-----'`--'   `--'`--`--`--' `----'`----'  `---' `----'`--''--' `----' 
                                                                        

  crimescene - Forensic Analysis Toolkit
  ©2026 anonymous blackhat OSINT team
"""

def run_command(cmd):
    try:
        subprocess.run(cmd, shell=True, check=True)
    except subprocess.CalledProcessError as e:
        print(f"[ERROR] Command failed: {e}")
    except KeyboardInterrupt:
        print("\n[!] Interrupted by user")
    except Exception as e:
        print(f"[ERROR] {e}")
    input("\nPress Enter to continue...")

def media_analysis():
    print("\n[*] Media Analysis")
    target = input("Enter target file or folder: ").strip()
    if not target:
        return
    out = input("Output JSON (optional, press Enter to skip): ").strip()
    if out:
        cmd = f"python3 tools/mediaanalys/media.py \"{target}\" -o \"{out}\""
    else:
        cmd = f"python3 tools/mediaanalys/media.py \"{target}\""
    run_command(cmd)

def media_comparison():
    print("\n[*] Media Comparison")
    f1 = input("Enter first file: ").strip()
    if not f1:
        return
    f2 = input("Enter second file: ").strip()
    if not f2:
        return
    out = input("Output JSON (optional): ").strip()
    html = input("Output HTML report (optional): ").strip()
    cmd = f"python3 tools/mediacomp/photo.py \"{f1}\" \"{f2}\""
    if out:
        cmd += f" --output \"{out}\""
    if html:
        cmd += f" --html \"{html}\""
    run_command(cmd)

def show_help():
    print("""
===============================================================
 guide 
===============================================================

   Media Analysis (media.py)
  ---------------------------------
  python3 tools/mediaanalys/media.py image.jpg
  python3 tools/mediaanalys/media.py folder/ -r -o report.json

   Media Comparison (photo.py)
  ---------------------------------
  python3 tools/mediacomp/photo.py img1.jpg img2.jpg
  python3 tools/mediacomp/photo.py folder/ --threshold 70
  python3 tools/mediacomp/photo.py img1.jpg img2.jpg --html report.html

===============================================================
""")
    input("Press Enter to continue...")

def main():
    while True:
        os.system('clear')
        print(BANNER)
        print("   Crimescene menu...")
        print("  1) Media Analysis (media.py)")
        print("  2) Media Comparison (photo.py)")
        print("  3) Help / Usage")
        print("  4) exit")
        choice = input("\nSelect option [1-4]: ").strip()
        if choice == '1':
            media_analysis()
        elif choice == '2':
            media_comparison()
        elif choice == '3':
            show_help()
        elif choice == '4':
            print("Exiting...")
            sys.exit(0)
        else:
            print("[ERROR!!....] Invalid option")
            input("Press Enter to continue...")

if __name__ == "__main__":
    main()