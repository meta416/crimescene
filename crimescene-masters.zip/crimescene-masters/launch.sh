clear

echo " ,-----.       ,--.                                                     "
echo "'  .--./,--.--.`--',--,--,--. ,---.  ,---.  ,---. ,---. ,--,--,  ,---.  "
echo "|  |    |  .--',--.|        || .-. :(  .-' | .--'| .-. :|      \| .-. : "
echo "'  '--'\|  |   |  ||  |  |  |\   --..-'  \)\ `--.\   --.|  ||  |\   --. "
echo " \`-----'\`--'   \`--'\`--\`--\`--' \`----'\`----'  \`---' \`----'\`--''--' \`----' "
echo "   Crimescene— Forensic Analysis Toolkit"
echo "  ©2026 anonymous blackhat OSINT team"

if ! command -v python3 &> /dev/null; then
    echo "[ERROR] Python3 not found. Please install Python3."
    exit 1
fi

echo "[*] Checking dependencies..."
python3 -c "import exifread, PIL, numpy" 2>/dev/null
if [ $? -ne 0 ]; then
    echo "[WARNING] Some dependencies missing. Run: pip install -r requirements.txt"
fi

echo ""
echo "   menu blyat"
echo "  1)  Media Analysis (media.py)"
echo "  2)  Media Comparison (photo.py)"
echo "  3)  Help / Usage"
echo "  4)  Exit"
echo ""

read -p "Select option [1-4]: " choice

case $choice in
    1)
        echo ""
        echo "[*] Running Media Analysis..."
        echo "Usage: python3 tools/mediaanalys/media.py <file/folder> [-o output.json]"
        echo ""
        read -p "Enter target file or folder: " target
        read -p "Output JSON file (optional): " outfile
        if [ -n "$outfile" ]; then
            python3 tools/mediaanalys/media.py "$target" -o "$outfile"
        else
            python3 tools/mediaanalys/media.py "$target"
        fi
        ;;
    2)
        echo ""
        echo "[*] Running Media Comparison..."
        echo "Usage: python3 tools/mediacomp/photo.py <file1> <file2> [--output result.json] [--html report.html]"
        echo ""
        read -p "Enter first file: " f1
        read -p "Enter second file: " f2
        read -p "Output JSON file (optional): " outfile
        read -p "Output HTML report (optional): " htmlfile
        cmd="python3 tools/mediacomp/photo.py \"$f1\" \"$f2\""
        if [ -n "$outfile" ]; then
            cmd="$cmd --output \"$outfile\""
        fi
        if [ -n "$htmlfile" ]; then
            cmd="$cmd --html \"$htmlfile\""
        fi
        eval $cmd
        ;;
    3)
        echo ""
        echo "  guide"
        echo "================================================================"
        echo ""
        echo "  Media Analysis (media.py)"
        echo "  ---------------------------------"
        echo "  python3 tools/mediaanalys/media.py image.jpg"
        echo "  python3 tools/mediaanalys/media.py folder/ -r -o report.json"
        echo ""
        echo "  Media Comparison (photo.py)"
        echo "  ---------------------------------"
        echo "  python3 tools/mediacomp/photo.py img1.jpg img2.jpg"
        echo "  python3 tools/mediacomp/photo.py folder/ --threshold 70"
        echo "  python3 tools/mediacomp/photo.py img1.jpg img2.jpg --html report.html"
        echo ""
        echo "================================================================"
        read -p "Press Enter to continue..."
        ;;
    4)
        echo "Exiting..."
        exit 0
        ;;
    *)
        echo "[errors...] Invalid option"
        ;;
esac

echo ""
read -p "Press Enter to close..."