#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import os
import json
import hashlib
import pickle
import argparse
import math
import logging
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

try:
    import numpy as np
    from PIL import Image, ExifTags
except ImportError as e:
    print(f"[ERROR] Missing dependency: {e}")
    print("Install: pip install pillow numpy")
    sys.exit(1)

logging.basicConfig(level=logging.INFO, format='[%(levelname)s] %(message)s')
logger = logging.getLogger(__name__)

CACHE_DIR = os.path.expanduser("~/.cache/srav_cache/")
os.makedirs(CACHE_DIR, exist_ok=True)

VERSION = "x.x"

def get_file_hash(filepath):
    hasher = hashlib.sha256()
    with open(filepath, 'rb') as f:
        for chunk in iter(lambda: f.read(65536), b''):
            hasher.update(chunk)
    return hasher.hexdigest()

def cache_load(filepath):
    h = get_file_hash(filepath)
    cache_file = os.path.join(CACHE_DIR, f"{h}.pkl")
    if os.path.exists(cache_file):
        with open(cache_file, 'rb') as f:
            return pickle.load(f)
    return None

def cache_save(filepath, data):
    h = get_file_hash(filepath)
    cache_file = os.path.join(CACHE_DIR, f"{h}.pkl")
    with open(cache_file, 'wb') as f:
        pickle.dump(data, f)

def extract_noise_fingerprint(img_array):
    if img_array is None or img_array.size == 0:
        return None
    img = img_array.astype(np.float32) / 255.0
    noise_std = float(np.std(img))
    hist, _ = np.histogram(img, bins=64, range=(0,1))
    hist = hist / hist.sum()
    ent = float(-np.sum(hist * np.log2(hist + 1e-10)))
    dx = np.diff(img, axis=1)
    dy = np.diff(img, axis=0)
    high_freq = float((np.std(dx) + np.std(dy)) / 2)
    return {
        'noise_std': noise_std,
        'entropy': ent,
        'freq_ratio_high': high_freq,
        'sample_size': img.size
    }

def extract_gps(exif_dict):
    if not exif_dict:
        return None
    try:
        gps_info = exif_dict.get('GPSInfo')
        if not gps_info:
            return None
        def get_gps_value(tag):
            val = gps_info.get(tag)
            if val and isinstance(val, tuple) and len(val) >= 2:
                return val[0] / val[1] if val[1] != 0 else 0.0
            return None
        lat = get_gps_value(2)
        lon = get_gps_value(4)
        if lat is None or lon is None:
            return None
        return {'latitude': lat, 'longitude': lon}
    except:
        return None

def extract_ela(img_array):
    if img_array is None:
        return None
    r, g, b = img_array[:,:,0], img_array[:,:,1], img_array[:,:,2]
    var = float(np.var(r) + np.var(g) + np.var(b))
    score = min(var / 10000, 1.0)
    return {'edited_score': score}

def extract_dead_pixels(img_array, threshold=0.05):
    if img_array is None:
        return None
    img = img_array.astype(np.float32) / 255.0
    dark = np.all(img < threshold, axis=2)
    bright = np.all(img > (1 - threshold), axis=2)
    dead_ratio = float((np.sum(dark) + np.sum(bright)) / img.size)
    return {'dead_pixel_ratio': dead_ratio}

def extract_parallax(img_array):
    if img_array is None:
        return None
    img = img_array.astype(np.float32) / 255.0
    dx = np.diff(img, axis=1)
    dy = np.diff(img, axis=0)
    var_dx = float(np.var(dx))
    var_dy = float(np.var(dy))
    return {'parallax_score': (var_dx + var_dy) / 2}

def extract_messengers(exif_dict):
    if not exif_dict:
        return []
    tags = ['ImageDescription', 'Software', 'Artist', 'Copyright', 'XPComment']
    messengers = []
    for tag in tags:
        val = exif_dict.get(tag)
        if val:
            val = str(val).lower()
            if 'whatsapp' in val:
                messengers.append('whatsapp')
            if 'telegram' in val:
                messengers.append('telegram')
            if 'signal' in val:
                messengers.append('signal')
            if 'viber' in val:
                messengers.append('viber')
    return list(set(messengers))

def extract_identifiers(img, exif_dict):
    ids = []
    if not exif_dict:
        return ids
    for tag in ['Artist', 'Copyright', 'ImageDescription', 'XPComment', 'XPAuthor']:
        val = exif_dict.get(tag)
        if val:
            val = str(val)
            if '@' in val:
                for part in val.split():
                    if '@' in part and '.' in part:
                        ids.append(part.strip())
            digits = ''.join(filter(str.isdigit, val))
            if len(digits) >= 7:
                ids.append(digits)
    return list(set(ids))

def extract_datetime(exif_dict):
    if not exif_dict:
        return None
    dt_str = exif_dict.get('DateTimeOriginal') or exif_dict.get('DateTime')
    if dt_str:
        try:
            for fmt in ['%Y:%m:%d %H:%M:%S', '%Y-%m-%d %H:%M:%S']:
                try:
                    return datetime.strptime(str(dt_str), fmt)
                except:
                    continue
        except:
            pass
    return None

def extract_all(filepath, use_cache=True):
    if use_cache:
        cached = cache_load(filepath)
        if cached:
            return cached

    result = {'_meta': {'file': str(filepath), 'hash': get_file_hash(filepath)}}
    try:
        img = Image.open(filepath)
        if img.mode != 'RGB':
            img = img.convert('RGB')
        img_array = np.array(img)

        exif_dict = {}
        exif_data = img.getexif()
        for tag_id, value in exif_data.items():
            tag_name = ExifTags.TAGS.get(tag_id, tag_id)
            exif_dict[tag_name] = value

        result['noise_fingerprint'] = extract_noise_fingerprint(img_array)
        result['gps'] = extract_gps(exif_dict)
        result['ela'] = extract_ela(img_array)
        result['dead_pixels'] = extract_dead_pixels(img_array)
        result['parallax'] = extract_parallax(img_array)
        result['exif_messengers'] = extract_messengers(exif_dict)
        result['user_identifiers'] = extract_identifiers(img, exif_dict)
        result['datetime'] = extract_datetime(exif_dict)

        if use_cache:
            cache_save(filepath, result)
        return result
    except Exception as e:
        logger.error(f"Error processing {filepath}: {e}")
        return {'error': str(e), '_meta': {'file': str(filepath)}}

def similarity_score(val1, val2, max_diff, invert=False):
    if val1 is None or val2 is None:
        return 0.5, 0.5
    diff = abs(val1 - val2)
    if max_diff == 0:
        sim = 1.0 if diff == 0 else 0.0
    else:
        sim = 1 - min(diff / max_diff, 1.0)
    if invert:
        sim = 1 - sim
    confidence = 1.0 - min(diff / (max_diff * 2), 0.5) if max_diff > 0 else 0.9
    return sim, confidence

def confidence_interval(probability, n_factors=9):
    std_err = 0.15 / math.sqrt(n_factors)
    margin = 1.96 * std_err * 100
    return max(0, probability - margin), min(100, probability + margin)

def factor_significance(diff, max_diff, sample_size=1000):
    if max_diff == 0:
        return "high" if diff == 0 else "low"
    ratio = diff / max_diff
    if ratio < 0.1:
        return "high"
    elif ratio < 0.3:
        return "medium"
    else:
        return "low"

def compare_images(d1, d2, weights):
    n1 = d1.get('noise_fingerprint', {})
    n2 = d2.get('noise_fingerprint', {})
    std_sim, std_conf = similarity_score(n1.get('noise_std'), n2.get('noise_std'), 0.05)
    ent_sim, ent_conf = similarity_score(n1.get('entropy'), n2.get('entropy'), 10.0)
    freq_sim, freq_conf = similarity_score(n1.get('freq_ratio_high'), n2.get('freq_ratio_high'), 0.5)
    noise_sim = std_sim * 0.4 + ent_sim * 0.3 + freq_sim * 0.3
    noise_conf = min(std_conf, ent_conf, freq_conf)

    g1 = d1.get('gps', {})
    g2 = d2.get('gps', {})
    if g1 and g2:
        lat1, lon1 = g1['latitude'], g1['longitude']
        lat2, lon2 = g2['latitude'], g2['longitude']
        dist = math.hypot(lat1 - lat2, lon1 - lon2) * 111
        gps_sim, gps_conf = similarity_score(dist, 0, 5.0)
    else:
        gps_sim, gps_conf = 0.5, 0.3

    ela1 = d1.get('ela', {})
    ela2 = d2.get('ela', {})
    if 'edited_score' in ela1 and 'edited_score' in ela2:
        ela_sim, ela_conf = similarity_score(ela1['edited_score'], ela2['edited_score'], 0.3)
    else:
        ela_sim, ela_conf = 0.5, 0.3

    dp1 = d1.get('dead_pixels', {})
    dp2 = d2.get('dead_pixels', {})
    if 'dead_pixel_ratio' in dp1 and 'dead_pixel_ratio' in dp2:
        dead_sim, dead_conf = similarity_score(dp1['dead_pixel_ratio'], dp2['dead_pixel_ratio'], 0.05)
    else:
        dead_sim, dead_conf = 0.5, 0.3

    p1 = d1.get('parallax', {})
    p2 = d2.get('parallax', {})
    if 'parallax_score' in p1 and 'parallax_score' in p2:
        par_sim, par_conf = similarity_score(p1['parallax_score'], p2['parallax_score'], 0.5)
    else:
        par_sim, par_conf = 0.5, 0.3

    m1 = set(d1.get('exif_messengers', []))
    m2 = set(d2.get('exif_messengers', []))
    if m1 and m2:
        mess_sim = len(m1 & m2) / max(len(m1), len(m2))
        mess_conf = 0.8 if mess_sim > 0 else 0.3
    else:
        mess_sim, mess_conf = 0.5, 0.3

    id1 = set(d1.get('user_identifiers', []))
    id2 = set(d2.get('user_identifiers', []))
    if id1 and id2:
        id_sim = len(id1 & id2) / max(len(id1), len(id2))
        id_conf = 0.8 if id_sim > 0 else 0.3
    else:
        id_sim, id_conf = 0.5, 0.3

    dt1 = d1.get('datetime')
    dt2 = d2.get('datetime')
    if dt1 and dt2:
        delta = abs((dt1 - dt2).total_seconds())
        time_sim, time_conf = similarity_score(delta, 0, 60)
    else:
        time_sim, time_conf = 0.5, 0.3

    factors = {
        'noise': {'sim': noise_sim, 'conf': noise_conf, 'weight': weights.get('noise', 0.45)},
        'gps': {'sim': gps_sim, 'conf': gps_conf, 'weight': weights.get('gps', 0.05)},
        'ela': {'sim': ela_sim, 'conf': ela_conf, 'weight': weights.get('ela', 0.05)},
        'dead': {'sim': dead_sim, 'conf': dead_conf, 'weight': weights.get('dead', 0.05)},
        'parallax': {'sim': par_sim, 'conf': par_conf, 'weight': weights.get('parallax', 0.05)},
        'messenger': {'sim': mess_sim, 'conf': mess_conf, 'weight': weights.get('messenger', 0.05)},
        'identifier': {'sim': id_sim, 'conf': id_conf, 'weight': weights.get('identifier', 0.05)},
        'time': {'sim': time_sim, 'conf': time_conf, 'weight': weights.get('time', 0.05)}
    }

    total_w = sum(f['weight'] for f in factors.values())
    if total_w == 0:
        total_w = 1.0
    for k in factors:
        factors[k]['weight'] /= total_w

    total_score = sum(f['sim'] * f['weight'] for f in factors.values())
    probability = total_score * 100
    avg_conf = sum(f['conf'] * f['weight'] for f in factors.values())
    ci_low, ci_high = confidence_interval(probability, len(factors))

    raw_values = {
        'noise_std': (n1.get('noise_std'), n2.get('noise_std')),
        'entropy': (n1.get('entropy'), n2.get('entropy')),
        'freq_ratio': (n1.get('freq_ratio_high'), n2.get('freq_ratio_high')),
        'gps': (d1.get('gps'), d2.get('gps')),
        'ela': (d1.get('ela', {}).get('edited_score'), d2.get('ela', {}).get('edited_score')),
        'dead_pixels': (d1.get('dead_pixels', {}).get('dead_pixel_ratio'), d2.get('dead_pixels', {}).get('dead_pixel_ratio')),
        'parallax': (d1.get('parallax', {}).get('parallax_score'), d2.get('parallax', {}).get('parallax_score')),
        'messengers': (d1.get('exif_messengers', []), d2.get('exif_messengers', [])),
        'identifiers': (d1.get('user_identifiers', []), d2.get('user_identifiers', [])),
        'datetime': (str(d1.get('datetime')), str(d2.get('datetime')))
    }

    return {
        'probability': probability,
        'confidence_interval': (ci_low, ci_high),
        'avg_confidence': avg_conf,
        'factors': factors,
        'raw_values': raw_values,
        'meta': {
            'file1': d1.get('_meta', {}).get('file', 'unknown'),
            'file2': d2.get('_meta', {}).get('file', 'unknown'),
            'hash1': d1.get('_meta', {}).get('hash', ''),
            'hash2': d2.get('_meta', {}).get('hash', '')
        }
    }

def format_confidence(conf):
    if conf > 0.7:
        return "high"
    elif conf > 0.4:
        return "medium"
    else:
        return "low"

def print_result(result, verbose=False):
    p = result['probability']
    ci_low, ci_high = result['confidence_interval']
    print(f"\nPAIR: {result['meta']['file1']} <-> {result['meta']['file2']}")
    print(f"  PROBABILITY: {p:.1f}%  (95% CI: {ci_low:.1f}% - {ci_high:.1f}%)")
    print(f"  OVERALL CONFIDENCE: {format_confidence(result['avg_confidence'])}")
    if verbose:
        print("  FACTORS:")
        for name, f in result['factors'].items():
            print(f"    {name:12s}: {f['sim']*100:5.1f}%  (weight: {f['weight']*100:4.1f}%, confidence: {format_confidence(f['conf'])})")
    print("-" * 60)

def main():
    parser = argparse.ArgumentParser(description='LO Proof Edition: image comparison with statistics')
    parser.add_argument('files', nargs='+', help='Images or folders')
    parser.add_argument('--output', '-o', help='Save JSON result')
    parser.add_argument('--html', help='Save HTML expert report')
    parser.add_argument('--threshold', type=int, default=0, help='Probability threshold (0-100)')
    parser.add_argument('--weights', default='{"noise":0.45,"gps":0.05,"ela":0.05,"dead":0.05,"parallax":0.05,"messenger":0.05,"identifier":0.05,"time":0.05}', help='Weights JSON')
    parser.add_argument('--no-cache', action='store_true', help='Disable cache')
    parser.add_argument('--verbose', action='store_true', help='Verbose output')
    args = parser.parse_args()

    if args.verbose:
        logger.setLevel(logging.DEBUG)

    use_cache = not args.no_cache

    try:
        weights = json.loads(args.weights)
    except:
        logger.error("Invalid weights JSON. Using defaults.")
        weights = json.loads('{"noise":0.45,"gps":0.05,"ela":0.05,"dead":0.05,"parallax":0.05,"messenger":0.05,"identifier":0.05,"time":0.05}')

    files = []
    for f in args.files:
        p = Path(f)
        if p.is_dir():
            for ext in ['*.jpg', '*.jpeg', '*.png', '*.webp', '*.tiff', '*.bmp']:
                files.extend(p.glob(ext))
        else:
            files.append(p)

    if not files:
        logger.error("No images found.")
        sys.exit(1)

    if len(files) < 2:
        logger.error("Need at least two files or a folder with images.")
        sys.exit(1)

    logger.info(f"Processing {len(files)} files...")
    data = {}
    with ThreadPoolExecutor(max_workers=min(len(files), 8)) as executor:
        future_to_file = {executor.submit(extract_all, str(f), use_cache): f for f in files}
        for future in as_completed(future_to_file):
            f = future_to_file[future]
            try:
                data[str(f)] = future.result()
            except Exception as e:
                logger.error(f"Error {f}: {e}")
                data[str(f)] = {'error': str(e)}

    logger.info("Comparing...")
    results = []
    file_list = list(data.keys())
    for i in range(len(file_list)):
        for j in range(i+1, len(file_list)):
            f1, f2 = file_list[i], file_list[j]
            d1, d2 = data[f1], data[f2]
            if 'error' in d1 or 'error' in d2:
                continue
            comp = compare_images(d1, d2, weights)
            if comp['probability'] >= args.threshold:
                results.append(comp)

    results.sort(key=lambda x: x['probability'], reverse=True)

    print("""                                                                       
 ,-----.       ,--.                                                     
'  .--./,--.--.`--',--,--,--. ,---.  ,---.  ,---. ,---. ,--,--,  ,---.  
|  |    |  .--',--.|        || .-. :(  .-' | .--'| .-. :|      \| .-. : 
'  '--'\|  |   |  ||  |  |  |\   --..-'  `)\ `--.\   --.|  ||  |\   --. 
 `-----'`--'   `--'`--`--`--' `----'`----'  `---' `----'`--''--' `----'                                                                       
""")
    print(f"COMPARISON RESULTS (threshold >= {args.threshold}%)")
    print(f"Pairs: {len(results)}")
    print("="*80)
    for r in results:
        print_result(r, args.verbose)

    if args.output:
        with open(args.output, 'w', encoding='utf-8') as f:
            json.dump(results, f, indent=2, ensure_ascii=False, default=str)
        logger.info(f"JSON saved: {args.output}")

    if args.html:
        html = f"""<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Expert Report - Image Comparison</title>
<style>
body {{ font-family: 'Segoe UI', Arial, sans-serif; background: #f5f5f5; padding: 30px; color: #222; }}
.container {{ max-width: 1200px; margin: 0 auto; }}
.pair {{ background: #fff; border-radius: 8px; padding: 20px; margin-bottom: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); border-left: 6px solid #007acc; }}
.prob {{ font-size: 2em; font-weight: bold; color: #007acc; }}
.ci {{ font-size: 1em; color: #555; }}
.meta {{ font-size: 0.85em; color: #888; margin-top: 5px; }}
.factors {{ display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 10px; margin-top: 15px; }}
.factor {{ background: #f9f9f9; padding: 10px; border-radius: 4px; }}
.factor .name {{ font-weight: bold; }}
.factor .sim {{ color: #007acc; }}
.conf-high {{ color: #2e7d32; }}
.conf-medium {{ color: #ed6c02; }}
.conf-low {{ color: #d32f2f; }}
.threshold {{ font-size: 0.9em; color: #555; }}
</style>
</head>
<body>
<div class="container">
<h1>Expert Report: Image Comparison</h1>
<p>Generated: {datetime.now().isoformat()} | Version: {VERSION}</p>
<p>Pairs: {len(results)} | Threshold: {args.threshold}%</p>
<hr>
"""
        for r in results:
            p = r['probability']
            ci_low, ci_high = r['confidence_interval']
            conf_label = format_confidence(r['avg_confidence'])
            html += f"""
<div class="pair">
  <div class="prob">{p:.1f}% <span class="ci">(95% CI: {ci_low:.1f}% - {ci_high:.1f}%)</span></div>
  <div class="meta">{r['meta']['file1']} <-> {r['meta']['file2']}</div>
  <div class="meta">Confidence: {conf_label} | Hash1: {r['meta']['hash1'][:12]}... | Hash2: {r['meta']['hash2'][:12]}...</div>
  <div class="factors">
"""
            for name, f in r['factors'].items():
                conf_class = f"conf-{format_confidence(f['conf'])}"
                html += f"""
    <div class="factor">
      <div class="name">{name}</div>
      <div class="sim">{f['sim']*100:.1f}%</div>
      <div class="weight">weight: {f['weight']*100:.1f}%</div>
      <div class="{conf_class}">confidence: {format_confidence(f['conf'])}</div>
    </div>
"""
            html += """
  </div>
</div>
"""
        html += """
</div>
</body>
</html>
"""
        with open(args.html, 'w', encoding='utf-8') as f:
            f.write(html)
        logger.info(f"HTML report saved: {args.html}")

if __name__ == '__main__':
    main()