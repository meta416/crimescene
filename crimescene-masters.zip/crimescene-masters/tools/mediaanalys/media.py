import os
import sys
import json
import argparse
import io
import re
import math
import wave
import struct
from pathlib import Path
import exifread
from PIL import Image, ImageChops
import numpy as np
import requests

try:
    import pyheif
except ImportError:
    pyheif = None

try:
    from scipy.ndimage import label, generate_binary_structure, sobel, gaussian_filter
    from scipy.signal import find_peaks
    from scipy.fft import fft, ifft
    HAS_SCIPY = True
except ImportError:
    HAS_SCIPY = False
    # заглушки
    def sobel(*a, **k): raise ImportError("scipy missing")
    def gaussian_filter(*a, **k): raise ImportError("scipy missing")
    def find_peaks(*a, **k): raise ImportError("scipy missing")
    def fft(*a, **k): raise ImportError("scipy missing")
    def ifft(*a, **k): raise ImportError("scipy missing")

MESSENGER_FINGERPRINTS = {
    'whatsapp': {
        'pattern': re.compile(r'WA[0-9]{4,}', re.I),
        'noise_profile': (0.012, 0.008, 0.45),
        'exif_indicators': ['WhatsApp', 'WA-']
    },
    'telegram': {
        'pattern': re.compile(r'TG[0-9A-Z]{6,}', re.I),
        'noise_profile': (0.018, 0.011, 0.32),
        'exif_indicators': ['Telegram', 'TG-']
    },
    'signal': {
        'pattern': re.compile(r'SIG[0-9A-Z]{5,}', re.I),
        'noise_profile': (0.015, 0.009, 0.38),
        'exif_indicators': ['Signal', 'SIG-']
    },
    'viber': {
        'pattern': re.compile(r'VB[0-9]{6,}', re.I),
        'noise_profile': (0.020, 0.013, 0.28),
        'exif_indicators': ['Viber', 'VB-']
    },
    'wechat': {
        'pattern': re.compile(r'WX[0-9]{8,}', re.I),
        'noise_profile': (0.025, 0.015, 0.22),
        'exif_indicators': ['WeChat', 'WX-']
    },
    'icloud': {
        'pattern': re.compile(r'icloud[0-9a-z]{8,}', re.I),
        'noise_profile': None,
        'exif_indicators': ['com.apple', 'icloud', 'appleid', 'CloudKit']
    },
    'google_photos': {
        'pattern': re.compile(r'gphotos[0-9a-z]{6,}', re.I),
        'noise_profile': None,
        'exif_indicators': ['googleusercontent', 'google.com', 'photos.google', 'drive.google']
    },
    'dropbox': {
        'pattern': re.compile(r'dbx[0-9a-z]{6,}', re.I),
        'noise_profile': None,
        'exif_indicators': ['dropbox.com', 'dbx-']
    }
}

def ela_analysis(img_path, quality=95):
    try:
        img = Image.open(img_path).convert('RGB')
        buf = io.BytesIO()
        img.save(buf, format='JPEG', quality=quality, subsampling=0)
        buf.seek(0)
        recompressed = Image.open(buf).convert('RGB')
        diff = ImageChops.difference(img, recompressed)
        arr = np.array(diff).astype(np.float32)
        mean_diff = np.mean(arr) / 255.0
        threshold = 0.05 * 255
        high_diff = np.sum(arr > threshold) / arr.size
        std_diff = np.std(arr) / 255.0
        edited_score = min(1.0, (mean_diff * 5 + std_diff * 3 + high_diff * 10))
        return {
            'mean_diff': float(mean_diff),
            'std_diff': float(std_diff),
            'high_diff_ratio': float(high_diff),
            'edited_score': float(edited_score),
            'verdict': 'edited' if edited_score > 0.3 else 'likely_original'
        }
    except Exception as e:
        return {'error': str(e)}

def dead_pixel_analysis(img_path):
    try:
        img = Image.open(img_path).convert('L')
        arr = np.array(img)
        dead = (arr < 5) | (arr > 250)
        total_dead = np.sum(dead)
        dead_ratio = total_dead / arr.size
        isolated_ratio = dead_ratio
        if HAS_SCIPY:
            structure = generate_binary_structure(2, 1)
            labeled, num_features = label(dead, structure=structure)
            counts = np.bincount(labeled.ravel())
            isolated = np.sum(counts == 1) - 1
            isolated_ratio = isolated / arr.size
        return {
            'dead_pixel_ratio': float(dead_ratio),
            'isolated_dead_ratio': float(isolated_ratio)
        }
    except Exception as e:
        return {'error': str(e)}

def parallax_error_analysis(img_path):
    try:
        if not HAS_SCIPY:
            return {'error': 'требуется scipy'}
        img = Image.open(img_path).convert('L')
        arr = np.array(img, dtype=np.float32)
        gx = sobel(arr, axis=0)
        gy = sobel(arr, axis=1)
        grad = np.hypot(gx, gy)
        mean_grad = np.mean(grad)
        std_grad = np.std(grad)
        var_grad = std_grad / (mean_grad + 1e-6)
        h, w = arr.shape
        if h >= 32 and w >= 32:
            blocks = arr[:h//32*32, :w//32*32].reshape(h//32, 32, w//32, 32).std(axis=(1,3))
            block_var = np.mean(blocks)
        else:
            block_var = np.std(arr)
        parallax_score = min(1.0, (var_grad * 0.5 + block_var / 50))
        verdict = 'outdoor_likely' if parallax_score > 0.4 else 'indoor_likely'
        return {
            'gradient_variation': float(var_grad),
            'block_variance': float(block_var),
            'parallax_score': float(parallax_score),
            'scene_verdict': verdict
        }
    except Exception as e:
        return {'error': str(e)}

def audio_environment_analysis(audio_path):
    try:
        if not audio_path.lower().endswith('.wav'):
            return {'error': 'только WAV, конвертируй ffmpeg'}
        if not HAS_SCIPY:
            return {'error': 'требуется scipy'}
        with wave.open(audio_path, 'rb') as wf:
            frames = wf.readframes(wf.getnframes())
            params = wf.getparams()
            n_channels, sampwidth, framerate, n_frames = params[:4]
            if sampwidth != 2:
                return {'error': 'только 16-bit PCM'}
            data = np.frombuffer(frames, dtype=np.int16)
            if n_channels == 2:
                data = data.reshape(-1, 2).mean(axis=1)
        fft_vals = np.fft.rfft(data)
        freqs = np.fft.rfftfreq(len(data), 1/framerate)
        magnitudes = np.abs(fft_vals)
        vib_mask = (freqs >= 20) & (freqs <= 200)
        vib_energy = np.sum(magnitudes[vib_mask]**2)
        total_energy = np.sum(magnitudes**2)
        vib_ratio = vib_energy / (total_energy + 1e-6)
        window_size = int(framerate * 0.02)
        rms = np.array([np.sqrt(np.mean(data[i:i+window_size]**2)) 
                        for i in range(0, len(data)-window_size, window_size)])
        peaks, _ = find_peaks(rms, height=np.max(rms)*0.1, distance=len(rms)//10)
        if len(peaks) > 2:
            decay = rms[peaks[0]] / (rms[peaks[1]] + 1e-6)
            ceps = np.abs(ifft(np.log(np.abs(fft(data)) + 1e-6)))**2
            ceps_peaks, _ = find_peaks(ceps[:framerate//2], height=np.mean(ceps)*2)
            echo_delay = ceps_peaks[0] / framerate if len(ceps_peaks) else 0
        else:
            decay = 1.0
            echo_delay = 0
        echo_score = (1 - decay) * 0.5 + min(1.0, echo_delay * 20)
        if vib_ratio > 0.15 or echo_score > 0.4:
            verdict = 'indoor'
        else:
            verdict = 'outdoor'
        return {
            'vibration_ratio': float(vib_ratio),
            'echo_score': float(echo_score),
            'decay': float(decay),
            'echo_delay_ms': float(echo_delay * 1000),
            'verdict': verdict
        }
    except Exception as e:
        return {'error': str(e)}

def noise_fingerprint_analysis(img_path):
    try:
        if not HAS_SCIPY:
            return {'error': 'требуется scipy'}
        img = Image.open(img_path).convert('L')
        arr = np.array(img, dtype=np.float32)
        smooth = gaussian_filter(arr, sigma=2)
        noise = arr - smooth
        noise_std = np.std(noise)
        noise_mean = np.mean(np.abs(noise))
        hist, _ = np.histogram(noise, bins=50, range=(-50, 50))
        hist = hist / (hist.sum() + 1e-6)
        entropy = -np.sum(hist * np.log2(hist + 1e-6))
        fft_noise = np.fft.fft2(noise)
        fft_mag = np.abs(np.fft.fftshift(fft_noise))
        h, w = fft_mag.shape
        center_h, center_w = h//2, w//2
        high_freq = fft_mag[center_h-10:center_h+10, center_w-10:center_w+10].sum()
        low_freq = fft_mag.sum() - high_freq
        freq_ratio = high_freq / (low_freq + 1e-6)
        best_match = None
        best_score = 0.0
        for name, data in MESSENGER_FINGERPRINTS.items():
            profile = data.get('noise_profile')
            if not profile:
                continue
            p_std, p_ent, p_freq = profile
            std_diff = abs(noise_std - p_std) / 0.02
            ent_diff = abs(entropy - p_ent) / 5.0
            freq_diff = abs(freq_ratio - p_freq) / 0.3
            score = 1.0 / (1.0 + std_diff + ent_diff + freq_diff)
            if score > best_score:
                best_score = score
                best_match = name
        return {
            'noise_std': float(noise_std),
            'noise_mean_abs': float(noise_mean),
            'entropy': float(entropy),
            'freq_ratio_high': float(freq_ratio),
            'likely_messenger': best_match,
            'confidence': float(best_score) if best_match else 0.0
        }
    except Exception as e:
        return {'error': str(e)}

def extract_user_identifiers(tags_str):
    result = {'identifiers': [], 'messengers': []}
    all_text = ' '.join(tags_str.values())
    emails = re.findall(r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}', all_text)
    if emails:
        result['identifiers'].extend(emails)
    usernames = re.findall(r'(?:user|username|id|account)[:=]\s*([a-zA-Z0-9_.-]{4,30})', all_text, re.I)
    if usernames:
        result['identifiers'].extend(usernames)
    uuids = re.findall(r'[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}', all_text, re.I)
    if uuids:
        result['identifiers'].extend(uuids)
    hashes = re.findall(r'\b[a-zA-Z0-9+/]{20,40}={0,2}\b', all_text)
    if hashes:
        result['identifiers'].extend(hashes)
    for messenger, data in MESSENGER_FINGERPRINTS.items():
        for indicator in data.get('exif_indicators', []):
            if indicator.lower() in all_text.lower():
                result['messengers'].append(messenger)
                break
        if data.get('pattern') and data['pattern'].search(all_text):
            if messenger not in result['messengers']:
                result['messengers'].append(messenger)
    result['identifiers'] = list(set(result['identifiers']))
    result['messengers'] = list(set(result['messengers']))
    return result

def extract_icc_info(tags):
    result = {}
    icc_bytes = None
    for k, v in tags.items():
        if 'ICC' in str(k) or 'profile' in str(k).lower():
            if isinstance(v, bytes) and len(v) > 100:
                icc_bytes = v
                break
            if isinstance(v, str) and 'ICC' in v:
                result['icc_description'] = v
    if icc_bytes:
        try:
            text = icc_bytes.decode('ascii', errors='ignore')
            manufacturers = {
                'Apple': ['Apple', 'iPhone', 'iPad', 'Mac'],
                'Samsung': ['Samsung', 'SM-'],
                'Google': ['Google', 'Pixel'],
                'Huawei': ['Huawei', 'HUAWEI'],
                'Xiaomi': ['Xiaomi', 'Redmi', 'POCO'],
                'OnePlus': ['OnePlus'],
                'Sony': ['Sony', 'Xperia'],
                'Nokia': ['Nokia'],
                'LG': ['LG-'],
                'Motorola': ['Motorola'],
                'Asus': ['ASUS'],
                'Realme': ['realme'],
                'Oppo': ['OPPO'],
                'Vivo': ['vivo']
            }
            for maker, keywords in manufacturers.items():
                for kw in keywords:
                    if kw in text:
                        result['manufacturer'] = maker
                        break
                if 'manufacturer' in result:
                    break
            model_match = re.search(r'(Model|Device|Camera)\s*[:=]\s*([A-Za-z0-9\-_]+)', text, re.I)
            if model_match:
                result['model'] = model_match.group(2).strip()
            result['icc_text_snippet'] = text[:200]
        except:
            pass
    if not result.get('manufacturer'):
        make = str(tags.get('Image Make', ''))
        model = str(tags.get('Image Model', ''))
        if make:
            result['manufacturer'] = make
        if model:
            result['model'] = model
    return result

def extract_cell_id_from_tags(tags):
    patterns = {
        'MCC': re.compile(r'(?:mcc|mobilecountrycode)', re.I),
        'MNC': re.compile(r'(?:mnc|mobilenetworkcode)', re.I),
        'LAC': re.compile(r'(?:lac|locationareacode)', re.I),
        'TAC': re.compile(r'(?:tac|trackingareacode)', re.I),
        'CID': re.compile(r'(?:cid|cellid|cell_id|bsid)', re.I),
    }
    result = {}
    raw_values = []
    for k, v in tags.items():
        str_k = str(k)
        str_v = str(v)
        raw_values.append(str_v)
        for key, regex in patterns.items():
            if regex.search(str_k):
                digits = re.search(r'\b(\d{3,8})\b', str_v)
                if digits:
                    result[key] = digits.group(1)
                    break
    if not result.get('CID'):
        for val in raw_values:
            if len(val) >= 5 and val.isdigit() and int(val) > 100:
                result['possible_CID'] = val
                break
    return result

def extract_gps(tags):
    try:
        lat_ref = str(tags.get('GPS GPSLatitudeRef', 'N'))
        lon_ref = str(tags.get('GPS GPSLongitudeRef', 'E'))
        lat = tags.get('GPS GPSLatitude')
        lon = tags.get('GPS GPSLongitude')
        if not lat or not lon:
            return {}
        def to_degrees(val):
            if isinstance(val, tuple):
                return float(val[0]) + float(val[1])/60 + float(val[2])/3600
            return float(val)
        lat_d = to_degrees(lat)
        lon_d = to_degrees(lon)
        if 'S' in lat_ref: lat_d = -lat_d
        if 'W' in lon_ref: lon_d = -lon_d
        return {'latitude': lat_d, 'longitude': lon_d}
    except:
        return {}

def extract_heif_metadata(filepath):
    if pyheif is None:
        return {}
    heif = pyheif.read_heif(filepath)
    exif_bytes = heif.metadata.get('Exif', b'')
    if not exif_bytes:
        return {}
    return exifread.process_file(io.BytesIO(exif_bytes), details=False)

def extract_standard_metadata(filepath):
    with open(filepath, 'rb') as f:
        tags = exifread.process_file(f, details=False)
    info = {}
    try:
        with Image.open(filepath) as img:
            info = {
                'format': img.format,
                'mode': img.mode,
                'width': img.width,
                'height': img.height,
                'dpi': img.info.get('dpi', None)
            }
    except:
        pass
    return tags, info

def extract_text_from_pdf(filepath):
    try:
        import PyPDF2
        with open(filepath, 'rb') as f:
            reader = PyPDF2.PdfReader(f)
            text = ''
            for page in reader.pages:
                text += page.extract_text()
        return text
    except:
        try:
            import pdfplumber
            with pdfplumber.open(filepath) as pdf:
                text = ''
                for page in pdf.pages:
                    text += page.extract_text()
            return text
        except:
            return None

def extract_text_from_docx(filepath):
    try:
        import docx
        doc = docx.Document(filepath)
        text = '\n'.join([para.text for para in doc.paragraphs])
        return text
    except:
        return None

def search_metadata_artifacts(text):
    patterns = {
        'windows_paths': re.compile(r'[a-zA-Z]:\\[^\\\s]+(?:\\[^\\\s]+)*', re.I),
        'unix_paths': re.compile(r'(?:/home/|/Users/|/root/|/tmp/|/var/|/etc/)[^\s]+', re.I),
        'ipv4': re.compile(r'\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b'),
        'email': re.compile(r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'),
        'usernames': re.compile(r'(?:user|username|login|name)[:=]\s*([a-zA-Z0-9_-]{3,})', re.I),
        'software_versions': re.compile(r'(?:version|ver\.?|v\.?)[:=]\s*([0-9.]+)', re.I),
        'urls': re.compile(r'https?://[^\s]+', re.I),
        'mac_address': re.compile(r'(?:[0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}'),
    }
    found = {}
    for name, regex in patterns.items():
        matches = regex.findall(text)
        if matches:
            found[name] = list(set(matches))
    return found

def analyze_document(filepath):
    ext = Path(filepath).suffix.lower()
    result = {}
    if ext == '.pdf':
        text = extract_text_from_pdf(filepath)
        if text:
            result['extracted_text_length'] = len(text)
            artifacts = search_metadata_artifacts(text)
            if artifacts:
                result['artifacts'] = artifacts
        else:
            result['error'] = 'не удалось извлечь текст (установи PyPDF2 или pdfplumber)'
    elif ext == '.docx':
        text = extract_text_from_docx(filepath)
        if text:
            result['extracted_text_length'] = len(text)
            artifacts = search_metadata_artifacts(text)
            if artifacts:
                result['artifacts'] = artifacts
        else:
            result['error'] = 'не удалось извлечь текст (установи python-docx)'
    elif ext == '.doc':
        result['error'] = 'поддерживается только .docx, конвертируй'
    return result

def extract_all(filepath):
    result = {
        'file': str(filepath),
        'size_bytes': os.path.getsize(filepath),
        'modified': os.path.getmtime(filepath)
    }
    ext = Path(filepath).suffix.lower()
    
    if ext in ('.heic', '.heif', '.jpg', '.jpeg', '.tif', '.tiff'):
        if ext in ('.heic', '.heif'):
            tags = extract_heif_metadata(filepath)
            info = {}
            try:
                heif = pyheif.read_heif(filepath)
                result['width'] = heif.size[0]
                result['height'] = heif.size[1]
                result['mode'] = heif.mode
            except:
                pass
        else:
            tags, info = extract_standard_metadata(filepath)
            result.update(info)
        
        tags_str = {str(k): str(v) for k, v in tags.items()}
        result['raw_tags'] = tags_str
        
        gps = extract_gps(tags)
        if gps:
            result['gps'] = gps

        cell = extract_cell_id_from_tags(tags)
        if cell:
            result['cell_info'] = cell

        ids = extract_user_identifiers(tags_str)
        if ids['identifiers']:
            result['user_identifiers'] = ids['identifiers']
        if ids['messengers']:
            result['exif_messengers'] = ids['messengers']
        
        icc = extract_icc_info(tags)
        if icc:
            result['icc_info'] = icc
        
        try:
            result['ela'] = ela_analysis(filepath)
        except Exception as e:
            result['ela_error'] = str(e)
        try:
            result['dead_pixels'] = dead_pixel_analysis(filepath)
        except Exception as e:
            result['dead_pixels_error'] = str(e)
        try:
            result['parallax'] = parallax_error_analysis(filepath)
        except Exception as e:
            result['parallax_error'] = str(e)
        try:
            result['noise_fingerprint'] = noise_fingerprint_analysis(filepath)
        except Exception as e:
            result['noise_fingerprint_error'] = str(e)
    
    elif ext in ('.wav', '.mp3', '.ogg', '.m4a'):
        try:
            result['audio_env'] = audio_environment_analysis(filepath)
        except Exception as e:
            result['audio_env_error'] = str(e)
    
    elif ext in ('.pdf', '.docx', '.doc'):
        doc_analysis = analyze_document(filepath)
        if doc_analysis:
            result['document_analysis'] = doc_analysis
    
    return result

def walk_dir(root, recursive=True):
    results = []
    for entry in os.scandir(root):
        if entry.is_file() and entry.name.lower().endswith(('.tif','.tiff','.heic','.heif','.jpg','.jpeg',
                                                           '.wav','.mp3','.ogg','.m4a','.pdf','.docx','.doc')):
            try:
                results.append(extract_all(entry.path))
            except Exception as e:
                results.append({'file': entry.path, 'error': str(e)})
        elif recursive and entry.is_dir():
            results.extend(walk_dir(entry.path, recursive))
    return results

def main():
    parser = argparse.ArgumentParser(description='script: изображения, аудио, PDF, DOCX')
    parser.add_argument('target', help='Файл или директория')
    parser.add_argument('-o', '--output', help='JSON-файл для сохранения')
    parser.add_argument('-r', '--recursive', action='store_true', default=True, help='Рекурсивный обход (по умолчанию)')
    parser.add_argument('--no-recursive', dest='recursive', action='store_false', help='Отключить рекурсию')
    args = parser.parse_args()

    target = Path(args.target)
    if target.is_file():
        data = extract_all(str(target))
    else:
        data = walk_dir(str(target), args.recursive)

    json_out = json.dumps(data, indent=2, default=str, ensure_ascii=False)
    if args.output:
        with open(args.output, 'w', encoding='utf-8') as f:
            f.write(json_out)
    else:
        print(json_out)

    print("""
                                                                        
 ,-----.       ,--.                                                     
'  .--./,--.--.`--',--,--,--. ,---.  ,---.  ,---. ,---. ,--,--,  ,---.  
|  |    |  .--',--.|        || .-. :(  .-' | .--'| .-. :|      \| .-. : 
'  '--'\|  |   |  ||  |  |  |\   --..-'  `)\ `--.\   --.|  ||  |\   --. 
 `-----'`--'   `--'`--`--`--' `----'`----'  `---' `----'`--''--' `----' 
                                                                                                    
""")
    if isinstance(data, dict):
        summary = generate_summary(data, str(target))
        print(summary)
    elif isinstance(data, list):
        print(f"Обработано файлов: {len(data)}")
        for i, item in enumerate(data[:3]):
            if isinstance(item, dict) and 'file' in item:
                print(f"\n--- Файл #{i+1} ---")
                print(generate_summary(item, item['file']))
        if len(data) > 3:
            print(f"\n... и ещё {len(data)-3} файлов (полный отчёт в JSON)")

def generate_summary(data, filepath):
    """
    Генерирует краткий текстовый отчёт по одному файлу.
    """
    lines = []
    lines.append(f"##краткий отчет##")
    lines.append(f"Файл: {Path(filepath).name}")
    lines.append(f"Размер: {data.get('size_bytes', 0)} байт")
    lines.append(f"Разрешение: {data.get('width', '?')}x{data.get('height', '?')}")
    lines.append(f"Формат: {data.get('format', '?')}")
    lines.append("")
    
    #ggppgpgpr
    gps = data.get('gps')
    if gps and 'latitude' in gps:
        lines.append(f"[GPS] Координаты: {gps['latitude']:.6f}, {gps['longitude']:.6f}")
        lines.append(f"[GPS] Ссылка: https://www.google.com/maps?q={gps['latitude']},{gps['longitude']}")
    else:
        lines.append("[GPS] Нет координат (удалены или не сохранены)")

    cell = data.get('cell_info', {})
    if cell:
        lines.append(f"[СОТЫ] MCC: {cell.get('MCC', '?')}, MNC: {cell.get('MNC', '?')}, LAC: {cell.get('LAC', '?')}, CID: {cell.get('CID', cell.get('possible_CID', '?'))}")
    else:
        lines.append("[СОТЫ] Нет данных о вышке")
    
    icc = data.get('icc_info', {})
    if icc.get('manufacturer'):
        lines.append(f"[ПРОИЗВОДИТЕЛЬ] {icc.get('manufacturer')} {icc.get('model', '')}")
    else:
        lines.append("[ПРОИЗВОДИТЕЛЬ] Не определён (ICC/EXIF стёрты)")

    exif_mess = data.get('exif_messengers', [])
    if exif_mess:
        lines.append(f"[EXIF-МЕССЕНДЖЕР] {', '.join(exif_mess)} (найдено в полях)")
    else:
        lines.append("[EXIF-МЕССЕНДЖЕР] Не найден")
    
    # Шумовой fingerprint
    noise = data.get('noise_fingerprint', {})
    if noise.get('likely_messenger') and noise.get('confidence', 0) > 0.1:
        lines.append(f"[ШУМОВОЙ ОТПЕЧАТОК] {noise['likely_messenger']} (уверенность: {noise['confidence']:.2f})")
    elif noise.get('likely_messenger'):
        lines.append(f"[ШУМОВОЙ ОТПЕЧАТОК] {noise['likely_messenger']} (уверенность низкая: {noise['confidence']:.2f})")
    else:
        lines.append("[ШУМОВОЙ ОТПЕЧАТОК] Не определён")
    
    #ella
    ela = data.get('ela', {})
    if ela.get('verdict'):
        lines.append(f"[РЕДАКТИРОВАНИЕ] {ela['verdict']} (score: {ela.get('edited_score', 0):.3f})")
    else:
        lines.append("[РЕДАКТИРОВАНИЕ] Не удалось определить")
    
    #hhh
    parallax = data.get('parallax', {})
    if parallax.get('scene_verdict'):
        lines.append(f"[СЦЕНА] {parallax['scene_verdict']} (по глубине/резкости)")
    else:
        lines.append("[СЦЕНА] Не определена")
    
    #audio
    audio = data.get('audio_env', {})
    if audio and audio.get('verdict'):
        lines.append(f"[АУДИО-ОКРУЖЕНИЕ] {audio['verdict']} (эхо: {audio.get('echo_score', 0):.2f}, вибрация: {audio.get('vibration_ratio', 0):.2f})")
    
    #doci
    doc = data.get('document_analysis', {})
    if doc:
        artifacts = doc.get('artifacts', {})
        if artifacts:
            lines.append("[ДОКУМЕНТ] Найдены артефакты:")
            for key, values in artifacts.items():
                lines.append(f"    - {key}: {', '.join(values[:3])}{' ...' if len(values)>3 else ''}")
        else:
            lines.append("[ДОКУМЕНТ] Текст извлечён, артефактов не найдено")
    
    # Идентификаторы (email, username, ID)
    ids = data.get('user_identifiers', [])
    if ids:
        lines.append(f"[ИДЕНТИФИКАТОРЫ] {', '.join(ids[:5])}{' ...' if len(ids)>5 else ''}")
    
    # Безопасность (битые пиксели)
    dead = data.get('dead_pixels', {})
    if dead and dead.get('dead_pixel_ratio', 0) > 0.01:
        lines.append(f"[БИТЫЕ ПИКСЕЛИ] {dead['dead_pixel_ratio']*100:.2f}% (сенсор засран или сильное сжатие)")
    
    lines.append("thanks bro :D")
    return '\n'.join(lines)

if __name__ == '__main__':
    main()