## fck////// forensic media tool by @fuckmetadon. Thanks for using

A powerful forensic toolkit for analyzing and comparing images, audio, and documents. Extract hidden metadata, detect edits, identify messengers, and compare file similarity.

---

## Features

### Media Analysis (`media.py`)
- **EXIF, HEIC, ICC** extraction
- **GPS, Cell ID** detection
- **ELA (Error Level Analysis)** — detects image edits
- **Dead pixel & parallax** analysis
- **Noise fingerprinting** — identify messenger apps (WhatsApp, Telegram, Signal, etc.)
- **Audio environment** analysis (indoor/outdoor)
- **PDF/DOCX** text extraction with artifact search (IPs, emails, paths)

### 🔬 Media Comparison (`photo.py`)
- **Noise fingerprint** comparison
- **GPS coordinate** matching
- **ELA score** comparison
- **Dead pixel ratio** analysis
- **Parallax / depth** analysis
- **Messenger & identifier** matching
- **Timestamps** comparison
- **Statistical confidence** with 95% CI
- **HTML/JSON** export

---

##Quick Start

### Installation
```bash
pip install exifread pyheif pillow numpy scipy requests PyPDF2 pdfplumber python-docx

#LAUNCH:
# bash launch.sh OR python3 launch.py

#Tool Path Purpose
#Media Analyzer tools/mediaanalys/media.py Extract all metadata from images, audio, #documents
#Media Comparator tools/mediacomp/photo.py Compare two or more images statistically

#USAGE:
#python3 tools/mediaanalys/media.py image.jpg -o result.json
#python3 tools/mediaanalys/media.py folder/ -r -o report.json

#WARNING, Necessarily: pip install -r requirements.txt


PLEASE NOTE: THE CREATORS OF THIS SCRIPT ARE NOT RESPONSIBLE FOR ANY OF THE CONSEQUENCES OF YOUR ACTIONS WITH THIS TOOL. BY CONTINUING TO USE IT, OR LAUNCHING THE TOOL, YOU AGREE TO THE RULES. YOU ARE FREE TO: DISTRIBUTE, MODIFY, AND REMODEL THE TOOL WITHOUT RESTRICTIONS. THE CREATORS DO NOT RESTRICTE YOU. BECAUSE FREEDOM EXISTS WHERE YOU Least Expect It.

tool author and developer: anonymous.